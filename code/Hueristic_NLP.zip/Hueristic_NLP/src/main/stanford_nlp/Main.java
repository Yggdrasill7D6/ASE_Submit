import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvException;
import edu.stanford.nlp.ling.*;
import edu.stanford.nlp.pipeline.*;
import simplenlg.features.Feature;
import simplenlg.features.Form;
import simplenlg.features.Tense;
import simplenlg.framework.LexicalCategory;
import simplenlg.framework.NLGFactory;
import simplenlg.framework.WordElement;
import simplenlg.lexicon.Lexicon;
import simplenlg.phrasespec.SPhraseSpec;
import simplenlg.realiser.english.Realiser;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    private static List<String> issues = new ArrayList<>();
    private static Map<Integer,String> pattern_code = new HashMap<>();
    private static final String inputFile = "../data/issue.csv";
    private static final String patternFile = "../data/Pattern_code_list.csv";
    private static final String outputPath = "";
    private static final String[] error_terms = {"error","issue","problem","exception","challenge","leak","pain","violation",
                                                 "null","conflict","loss","fault","failure","glitch","mistake",
                                                 "trouble","mess","breakage","leakage","segfault","spam","typo","404","NaN"};
    private static final String[] negative_verb = {"miss","fail","break","stick","stop","pollute","refuse","complain","remove",
                                                    "delete","ignore","block","clear","crash","interfere","lack","reject",
                                                    "disappear","revert","suffer","vanish","terminate","trim","die","delay",
                                                    "expire","freeze","forget","mishandle","bypass","shut"};
    private static final String[] undesired_adj = {"vulnerable", "invalid","undefined", "blank", "different", "weird",
                                                    "unreadable", "unusable", "unable", "wrongly","unexpected", "null",
                                                    "reluctant","confused","empty","incompatible","abnormal","annoying",
                                                    "bad","blocked","broken","counter-intuitive","corrupt","dead","dirty",
                                                    "duplicate","empty","erroneous","inaccessible","inappropriate","wrong",
                                                    "incorrect","inconsistent","incredible","indefinitely","inefficient",
                                                    "infinite","insecure","lost","meaningless","messed up","misleading",
                                                    "misplaced","missing","mistakenly","out-of-date","outdated","painful",
                                                    "poor","reduced","redundant","repeated","reversed","silly","slow",
                                                    "strange","spurious","stripped","tedious","truncated","ugly","zombie",
                                                    "unacceptable","unclickable","undesirable","undesired","unfriendly",
                                                    "uninitialized","unresponsive","unsecure","unstable","unstyled",
                                                    "untrusted","voided","wacky","vulnerable","stuck","low"};
    private static List<String> error_term_list = null;
    private static List<String> verb_list = null;
    private static List<String[]> list = new ArrayList<>();
    private static final boolean toCSV = true;

    public static void main(String[] args){
        readDocs();
        readPattern();
        System.out.println(pattern_code);
        //issues.add("I'd rather like it to land in my project folder");
        // set up pipeline properties
        Properties props = new Properties();
        // set the list of annotators to run
        props.setProperty("annotators", "tokenize,pos,lemma,ner,parse");
        // build pipeline
        StanfordCoreNLP pipeline = new StanfordCoreNLP(props);

        //initialize error_term_list
        Set<String> set = new HashSet<>();
        for (String error : error_terms) {
            set.add(error);
            set.add(getPlural(error));
        }
        error_term_list = new ArrayList<>(set);

        set.clear();
        //initialize verb_list
        for (String verb : negative_verb) {
            set.add(verb);
            set.addAll(getTense(verb,"all"));
        }
        verb_list = new ArrayList<>(set);


        //System.out.println(error_term_list);
        //System.out.println(verb_list);

        //createPOSForAll(pipeline);
        generatePattern(pipeline);


    }

    public static void generatePattern(StanfordCoreNLP pipeline){
        int counter = 0;
        list.clear();

        for (String issue : issues) {
            counter++;
            System.out.println(counter);
//            System.out.println("Issue:");
//            System.out.println(issue);

            // create a document object
            CoreDocument document = new CoreDocument(issue);
            // annnotate the document
            pipeline.annotate(document);

            String etd_pattern = "";
            String[] etd_data = new String[1];

            String ps_pattern = "";
            String[] ps_data = new String[1];

            for (CoreSentence sentence : document.sentences()) {
//                System.out.println("Sentence:");
//                System.out.println(sentence);

                List<CoreLabel> tokens = sentence.tokens();
                List<String> cleanTokens = tokenCleaning(tokens);
                List<String> posTags = sentence.posTags();

                //Check patterns for ETD, pattern 1-36
                //etd_pattern += checkETD(etd_pattern,cleanTokens,posTags);

                //Check patterns for PS, pattern 37-63
                ps_pattern += checkPS(ps_pattern,cleanTokens,posTags);


            }

            if(etd_pattern.length() > 1 || ps_pattern.length() > 1) {
                System.out.println(etd_pattern);
                System.out.println(ps_pattern);
            }

            //etd_data[0] = etd_pattern;
            ps_data[0] = ps_pattern;

            //list.add(etd_data);
            list.add(ps_data);

            if(counter % 200 == 0){
                writeToCSV("_"+counter+".csv");
                list.clear();
            }

//            System.out.println("Pos tags:");
//            System.out.println(annotations.trim());
//            System.out.println();

        }

        //writeToCSV("_result.csv");
    }

    public static String checkETD(String pattern,List<String> cleanTokens, List<String> posTags){
        String str = "";
        //Check patterns for ETD
        if(hasPattern1(cleanTokens,posTags) && !pattern.contains(pattern_code.get(1)))
            str += pattern_code.get(1)+",";

        if(hasPattern2(cleanTokens,posTags) && !pattern.contains(pattern_code.get(2)))
            str += pattern_code.get(2)+",";

        if(hasPattern3(cleanTokens,posTags) && !pattern.contains(pattern_code.get(3)))
            str += pattern_code.get(3)+",";

        if(hasPattern4(cleanTokens,posTags) && !pattern.contains(pattern_code.get(4)))
            str += pattern_code.get(4)+",";

        if(hasPattern5(cleanTokens,posTags) && !pattern.contains(pattern_code.get(5)))
            str += pattern_code.get(5)+",";

        if(hasPattern6(cleanTokens,posTags) && !pattern.contains(pattern_code.get(6)))
            str += pattern_code.get(6)+",";

        if(hasPattern7(cleanTokens,posTags) && !pattern.contains(pattern_code.get(7)))
            str += pattern_code.get(7)+",";

        if(hasPattern8(cleanTokens,posTags) && !pattern.contains(pattern_code.get(8)))
            str += pattern_code.get(8)+",";

        if(hasPattern9(cleanTokens,posTags) && !pattern.contains(pattern_code.get(9)))
            str += pattern_code.get(9)+",";

        if(hasPattern10(cleanTokens,posTags) && !pattern.contains(pattern_code.get(10)))
            str += pattern_code.get(10)+",";

        if(hasPattern11(cleanTokens,posTags) && !pattern.contains(pattern_code.get(11)))
            str += pattern_code.get(11)+",";

        if(hasPattern12(cleanTokens,posTags) && !pattern.contains(pattern_code.get(12)))
            str += pattern_code.get(12)+",";

        if(hasPattern13(cleanTokens,posTags) && !pattern.contains(pattern_code.get(13)))
            str += pattern_code.get(13)+",";

        if(hasPattern14(cleanTokens,posTags) && !pattern.contains(pattern_code.get(14)))
            str += pattern_code.get(14)+",";

        if(hasPattern15(cleanTokens,posTags) && !pattern.contains(pattern_code.get(15)))
            str += pattern_code.get(15)+",";

        if(hasPattern16(cleanTokens,posTags) && !pattern.contains(pattern_code.get(16)))
            str += pattern_code.get(16)+",";

        if(hasPattern17(cleanTokens,posTags) && !pattern.contains(pattern_code.get(17)))
            str += pattern_code.get(17)+",";

        if(hasPattern18(cleanTokens,posTags) && !pattern.contains(pattern_code.get(18)))
            str += pattern_code.get(18)+",";

        if(hasPattern19(cleanTokens,posTags) && !pattern.contains(pattern_code.get(19)))
            str += pattern_code.get(19)+",";

        if(hasPattern20(cleanTokens,posTags) && !pattern.contains(pattern_code.get(20)))
            str += pattern_code.get(20)+",";

        if(hasPattern21(cleanTokens,posTags) && !pattern.contains(pattern_code.get(21)))
            str += pattern_code.get(21)+",";

        if(hasPattern22(cleanTokens,posTags) && !pattern.contains(pattern_code.get(22)))
            str += pattern_code.get(22)+",";

        if(hasPattern23(cleanTokens,posTags) && !pattern.contains(pattern_code.get(23)))
            str += pattern_code.get(23)+",";

        if(hasPattern24(cleanTokens,posTags) && !pattern.contains(pattern_code.get(24)))
            str += pattern_code.get(24)+",";

        if(hasPattern25(cleanTokens,posTags) && !pattern.contains(pattern_code.get(25)))
            str += pattern_code.get(25)+",";

        if(hasPattern26(cleanTokens,posTags) && !pattern.contains(pattern_code.get(26)))
            str += pattern_code.get(26)+",";

        if(hasPattern27(cleanTokens,posTags) && !pattern.contains(pattern_code.get(27)))
            str += pattern_code.get(27)+",";

        if(hasPattern28(cleanTokens,posTags) && !pattern.contains(pattern_code.get(28)))
            str += pattern_code.get(28)+",";

        if(hasPattern29(cleanTokens,posTags) && !pattern.contains(pattern_code.get(29)))
            str += pattern_code.get(29)+",";

        if(hasPattern30(cleanTokens,posTags) && !pattern.contains(pattern_code.get(30)))
            str += pattern_code.get(30)+",";

        if(hasPattern31(cleanTokens,posTags) && !pattern.contains(pattern_code.get(31)))
            str += pattern_code.get(31)+",";

        if(hasPattern32(cleanTokens,posTags) && !pattern.contains(pattern_code.get(32)))
            str += pattern_code.get(32)+",";

        if(hasPattern33(cleanTokens,posTags) && !pattern.contains(pattern_code.get(33)))
            str += pattern_code.get(33)+",";

        if(hasPattern34(cleanTokens,posTags) && !pattern.contains(pattern_code.get(34)))
            str += pattern_code.get(34)+",";

        if(hasPattern35(cleanTokens,posTags) && !pattern.contains(pattern_code.get(35)))
            str += pattern_code.get(35)+",";

        if(hasPattern36(cleanTokens,posTags) && !pattern.contains(pattern_code.get(36)))
            str += pattern_code.get(36)+",";

        return str;
    }

    public static String checkPS(String pattern,List<String> cleanTokens, List<String> posTags){
        String str = "";
        if(hasPattern37(cleanTokens,posTags) && !pattern.contains(pattern_code.get(37)))
            str += pattern_code.get(37)+",";

        if(hasPattern38(cleanTokens,posTags) && !pattern.contains(pattern_code.get(38)))
            str += pattern_code.get(38)+",";

        if(!str.contains(pattern_code.get(37)) && hasPattern39(cleanTokens,posTags) && !pattern.contains(pattern_code.get(39)))
            str += pattern_code.get(39)+",";

        if(hasPattern40(cleanTokens,posTags) && !pattern.contains(pattern_code.get(40)))
            str += pattern_code.get(40)+",";

        if(hasPattern41(cleanTokens,posTags) && !pattern.contains(pattern_code.get(41)))
            str += pattern_code.get(41)+",";

        if(hasPattern42(cleanTokens,posTags) && !pattern.contains(pattern_code.get(42)))
            str += pattern_code.get(42)+",";

        if(hasPattern43(cleanTokens,posTags) && !pattern.contains(pattern_code.get(43)))
            str += pattern_code.get(43)+",";

        if(hasPattern44(cleanTokens,posTags) && !pattern.contains(pattern_code.get(44)))
            str += pattern_code.get(44)+",";

        if(hasPattern45(cleanTokens,posTags) && !pattern.contains(pattern_code.get(45)))
            str += pattern_code.get(45)+",";

        if(hasPattern46(cleanTokens,posTags) && !pattern.contains(pattern_code.get(46)))
            str += pattern_code.get(46)+",";

        if(hasPattern47(cleanTokens,posTags) && !pattern.contains(pattern_code.get(47)))
            str += pattern_code.get(47)+",";

        if(hasPattern48(cleanTokens,posTags) && !pattern.contains(pattern_code.get(48)))
            str += pattern_code.get(48)+",";

        if(hasPattern49(cleanTokens,posTags) && !pattern.contains(pattern_code.get(49)))
            str += pattern_code.get(49)+",";

        if(hasPattern50(cleanTokens,posTags) && !pattern.contains(pattern_code.get(50)))
            str += pattern_code.get(50)+",";

        if(hasPattern51(cleanTokens,posTags) && !pattern.contains(pattern_code.get(51)))
            str += pattern_code.get(51)+",";

        if(hasPattern52(cleanTokens,posTags) && !pattern.contains(pattern_code.get(52)))
            str += pattern_code.get(52)+",";

        if(hasPattern53(cleanTokens,posTags) && !pattern.contains(pattern_code.get(53)))
            str += pattern_code.get(53)+",";

        if(hasPattern54(cleanTokens,posTags) && !pattern.contains(pattern_code.get(54)))
            str += pattern_code.get(54)+",";

        if(hasPattern55(cleanTokens,posTags) && !pattern.contains(pattern_code.get(55)))
            str += pattern_code.get(55)+",";

        if(hasPattern56(cleanTokens,posTags) && !pattern.contains(pattern_code.get(56)))
            str += pattern_code.get(56)+",";

        if(hasPattern57(cleanTokens,posTags) && !pattern.contains(pattern_code.get(57)))
            str += pattern_code.get(57)+",";

        if(hasPattern58(cleanTokens,posTags) && !pattern.contains(pattern_code.get(58)))
            str += pattern_code.get(58)+",";

        if(hasPattern59(cleanTokens,posTags) && !pattern.contains(pattern_code.get(59)))
            str += pattern_code.get(59)+",";

        if(hasPattern60(cleanTokens,posTags) && !pattern.contains(pattern_code.get(60)))
            str += pattern_code.get(60)+",";

        if(hasPattern61(cleanTokens,posTags) && !pattern.contains(pattern_code.get(61)))
            str += pattern_code.get(61)+",";

        if(hasPattern62(cleanTokens,posTags) && !pattern.contains(pattern_code.get(62)))
            str += pattern_code.get(62)+",";

        if(hasPattern63(cleanTokens,posTags) && !pattern.contains(pattern_code.get(63)))
            str += pattern_code.get(63)+",";

        if(hasPattern64(cleanTokens,posTags) && !pattern.contains(pattern_code.get(64)))
            str += pattern_code.get(64)+",";

        if(hasPattern65(cleanTokens,posTags) && !pattern.contains(pattern_code.get(65)))
            str += pattern_code.get(65)+",";

        if(hasPattern66(cleanTokens,posTags) && !pattern.contains(pattern_code.get(66)))
            str += pattern_code.get(66)+",";

        return str;
    }

    public static boolean hasPattern1(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "according"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("according")){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                index++;
                //find DT/PRP$
                if(index >= cleanTokens.size() || (!posTags.get(index).equals("DT") && !posTags.get(index).equals("PRP$")))
                    continue;

                index++;
                //find "documentation"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("documentation"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern2(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "attempting\attempted"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("attempting") || token.equalsIgnoreCase("attempted")){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern3(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "possible\possibility"
        String[] w_possible = {"possible","possibility","ok"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_possible)){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                //find VB
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern4(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "better"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("better")){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern5(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "can"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("can")){
                //find "I/we"
                index++;
                if(index >= cleanTokens.size() || (!cleanTokens.get(index).equalsIgnoreCase("i") && !cleanTokens.get(index).equalsIgnoreCase("we")))
                    continue;

                //find VB
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equals("VB") || posTags.get(index).equals("VBP") ){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern6(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "consider/considering"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("consider") || token.equalsIgnoreCase("considering")){
                index++;
                //find VBG
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VBG"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern7(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "envision"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("envision")){
                index++;
                //find "that"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("that"))
                    continue;

                index++;
                //find NN/NNS/NNP
                if(index >= cleanTokens.size() || (!posTags.get(index).equals("NN") && !posTags.get(index).equals("NNS") && !posTags.get(index).equals("NNP")))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern8(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] w_expect = {"expect","expected","expects","expecting"};
        //find "expect"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_expect)){
                //find "to"
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern9(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //similar words
        String[] w_example = {"eg","e.g","e.g.","say","context"};
        String[] subject = {"PRP","PRP$","NN","NNS","NNP"};
        String[] verb = {"VB","VBP","VBZ","VBN","VBD"};
        //find "for example"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("for")){
                index++;
                //find "example"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("example"))
                    continue;

                //find subject
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !hasToken(posTags.get(index),verb))
                    continue;

                return true;
            }else if (hasToken(token,w_example)){
                //find subject
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !hasToken(posTags.get(index),verb))
                    continue;


                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern10(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] w_goal = {"goal","intention","idea"};
        //find "goal"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_goal)){
                //find "is/was"
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("is") || cleanTokens.get(index).equalsIgnoreCase("was") ){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "to"
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern11(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "going"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("going") || token.equalsIgnoreCase("went")){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern12(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] w_have = {"have","has","had","having"};
        //find "have"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_have)){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                index++;
                //find VB
                int flex = 2;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern13(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "hope\hoping"
        String[] w_hope = {"hope","hoping","hopes","hoped"};
        String[] subject = {"PRP","PRP$"};
        String[] noun = {"NN","NNS","NNP"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_hope)){
                index++;
                //find "to"
                if(index >= cleanTokens.size())
                    continue;

                if(cleanTokens.get(index).equalsIgnoreCase("to")){
                    index++;
                    //find VB
                    if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                        continue;

                    return true;
                    
                } else if (cleanTokens.get(index).equalsIgnoreCase("for")) {
                    //find "NN"
                    int flex = 2;
                    index++;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),noun)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;
                }else{
                    //find subject
                    int flex = 3;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),subject)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;

                }
            }

        }

        return false;
    }

    public static boolean hasPattern14(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] w_build = {"implementing","implemented","implement","build","building","built"};
        String[] noun = {"NN","NNP","NNS"};
        //find "implement/build"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_build)){
                //find "NN"
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;


                //find "with"/"that"
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("that") || cleanTokens.get(index).equalsIgnoreCase("with")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern15(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "in"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("in")){
                index++;
                //find "order"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("order"))
                    continue;

                //find "to"
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "VB"
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern16(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] predicate = {"VBG","VB","NN","CD","NNS","NNP"};
        //find "instead of"/"rather than"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("instead")){
                index++;
                //find "of"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equals("of"))
                    continue;

                //find predicate
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),predicate)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            } else if (token.equalsIgnoreCase("rather")) {
                index++;
                //find "than"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equals("than"))
                    continue;

                //find predicate
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),predicate)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;

            }

        }


        return false;
    }

    public static boolean hasPattern17(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "is"
        String[] dt = {"a","an","any","the"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("is")){
                index++;
                //find "there"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("there"))
                    continue;

                index++;
                //find "a"
                if(index >= cleanTokens.size() || !hasToken(cleanTokens.get(index),dt))
                    continue;

                //find "way"
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("way")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            } else if (token.equalsIgnoreCase("know")) {
                index++;
                //find "a"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("a"))
                    continue;

                //find "way"
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("way")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern18(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] noun = {"NN","NNP","NNS"};
        //find "learning"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("learning")){
                index++;
                //find "with"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("with"))
                    continue;

                //find NN
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern19(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] w_to = {"to","into","at"};
        String[] verb = {"VB","VBG","VBN","NN"};
        String[] noun = {"NN","NNP","NNS"};
        //find "looking"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("looking")){
                index++;
                //find TO
                if(index >= cleanTokens.size())
                    continue;
                if (cleanTokens.get(index).equalsIgnoreCase("for")) {
                    //find NN
                    int flex = 4;
                    index++;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),noun)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;
                } else if (hasToken(cleanTokens.get(index),w_to)) {
                    //find VB/NN
                    int flex = 2;
                    index++;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),verb)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;
                }

            }

        }


        return false;
    }

    public static boolean hasPattern20(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "make"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("make")){
                index++;
                //find "sense"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("sense"))
                    continue;

                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                //find VB
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB") || posTags.get(index).equalsIgnoreCase("NN")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern21(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] noun = {"NN","NNP","NNS"};
        //find "i"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("i")){
                index++;
                //find "mean"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("mean"))
                    continue;

                //find NN
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern22(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] subject = {"NN","NNP","NNS","PRP"};
        //find subject
        for(int i = 0; i < cleanTokens.size(); i++) {
            index = i;
            String pos = posTags.get(index);
            if(hasToken(pos,subject)){
                //find "must"
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("must")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern23(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] w_need = {"need","needs","needed"};
        String[] noun = {"NN","NNP","NNS","CD"};
        String[] verb = {"is","was","were","are","that"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            String pos = posTags.get(index);
            //find "need"
            if(hasToken(token,w_need)){
                //find "to" or NN
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to") || hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if (cleanTokens.get(index).equalsIgnoreCase("to")) {
                    index++;
                    //find VB
                    if(index >= cleanTokens.size() || (!posTags.get(index).equals("VB") && !posTags.get(index).equals("NN")))
                        continue;

                    return true;
                } else if (hasToken(posTags.get(index),noun) && !cleanTokens.get(index).equalsIgnoreCase("help")) {
                    return true;
                } else if (cleanTokens.get(index).equalsIgnoreCase("help")) {
                    index++;
                    //find VBG
                    if(index >= cleanTokens.size() || !posTags.get(index).equals("VBG"))
                        continue;

                    return true;
                }

            } else if (hasToken(pos,noun)) {
                //find verb
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),verb)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "need"
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),w_need)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;

            }
            
        }


        return false;
    }

    public static boolean hasPattern24(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "normally"
        String[] w_normally = {"normally","basically","typically","ideally"};
        String[] subject = {"PRP","PRP$","NN","NNP","NNS"};
        String[] predicate = {"VB","VBD","VBP","VBZ","VBN","MD"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_normally)){
                //find subject
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find predicate
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),predicate)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern25(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "planning"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("planning")){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || (!cleanTokens.get(index).equalsIgnoreCase("to") && !cleanTokens.get(index).equalsIgnoreCase("on")))
                    continue;

                index++;
                //find VB/VBG
                if(index >= cleanTokens.size() || (!posTags.get(index).equals("VB") && !posTags.get(index).equals("VBG")))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern26(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "require"
        String[] w_require = {"require","requires","required"};
        String[] noun = {"NN","NNS","NNP","CD"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_require)){
                //find noun
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern27(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "should"
        String[] w_should = {"should","shall","will"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_should)){
                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern28(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "supposed"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("supposed")){
                index++;
                //find "to"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("to"))
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern29(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "think"
        String[] w_think = {"think","thought","thinking"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_think)){
                index++;
                //find "of/about"
                if(index >= cleanTokens.size() || (!cleanTokens.get(index).equalsIgnoreCase("about") && !cleanTokens.get(index).equalsIgnoreCase("of")))
                    continue;

                index++;
                //find VBG
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VBG"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern30(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "trying"
        String[] w_try = {"trying","try","tried"};
        String[] noun = {"NN","NNS","NNP"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_try)){
                index++;
                //find VBG
                if(index >= cleanTokens.size())
                    continue;

                if (cleanTokens.get(index).equalsIgnoreCase("to")) {
                    index++;
                    //find VB
                    int flex = 2;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(posTags.get(index).equalsIgnoreCase("VB") || posTags.get(index).equalsIgnoreCase("NN")){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                    
                    return true;
                } else if (!token.equalsIgnoreCase("tried")) {
                    //find noun
                    int flex = 2;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),noun)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    //find IN
                    index++;
                    flex = 2;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(posTags.get(index).equalsIgnoreCase("IN")){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;

                }


            }

        }


        return false;
    }

    public static boolean hasPattern31(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "using"
        String[] noun = {"NN","NNS","NNP","PRP"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("using") || token.equalsIgnoreCase("use")){
                //find noun
                index++;
                int flex = 3;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "to"
                index++;
                flex = 4;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || (!posTags.get(index).equals("VB") && !posTags.get(index).equals("NN")))
                    continue;

                return true;
            }

            /*if(token.equalsIgnoreCase("i") || token.equalsIgnoreCase("we")){
                //find "using"
                index++;
                int flex = 4;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("using") || cleanTokens.get(index).equalsIgnoreCase("use")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find noun
                index++;
                flex = 3;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "to"
                index++;
                flex = 4;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }*/
        }

        return false;
    }

    public static boolean hasPattern32(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "want"
        String[] w_want = {"want","wants","wanted"};
        String[] subject = {"NN","NNS","NNP","PRP"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,w_want)){
                index++;
                int flex = 3;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to") || hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if (cleanTokens.get(index).equalsIgnoreCase("to")) {
                    index++;
                    //find VB
                    if(index >= cleanTokens.size() || (!posTags.get(index).equals("VB") && !posTags.get(index).equals("NN")))
                        continue;

                    return true;

                } else if (posTags.get(index).equalsIgnoreCase("PRP")) {
                    //find JJ
                    flex = 2;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(posTags.get(index).equalsIgnoreCase("JJ")){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;

                }


            } else if (token.equalsIgnoreCase("wan")) {
                index++;
                //find "na"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("na"))
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern33(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find "working"
        String[] noun = {"NN","NNS","NNP"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("working")){
                index++;
                //find VBG
                if(index >= cleanTokens.size())
                    break;
                else if (cleanTokens.get(index).equalsIgnoreCase("to")) {
                    index++;
                    //find VB
                    if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                        continue;

                    return true;
                } else if (cleanTokens.get(index).equalsIgnoreCase("on") || cleanTokens.get(index).equalsIgnoreCase("with")) {
                    //find VBG/NN
                    int flex = 3;
                    index++;
                    boolean isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(posTags.get(index).equalsIgnoreCase("VBG") || hasToken(posTags.get(index),noun)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                    return true;
                }

            }

        }


        return false;
    }

    public static boolean hasPattern34(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find MD
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            String[] adj = {"JJ","JJR","JJS"};
            if(pos.equalsIgnoreCase("MD")){
                //find "be"
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("be")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find JJ
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),adj)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;


                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern35(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        //find MD
        String[] w_like = {"like","love"};
        //String[] noun = {"NN","NNS","NNP","PRP"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            if(pos.equalsIgnoreCase("MD")){
                index++;
                //find "like"/"love"
                if(index >= cleanTokens.size() || !hasToken(cleanTokens.get(index),w_like))
                    continue;

                //find "to"
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                index++;
                //find VB
                if(index >= cleanTokens.size() || !posTags.get(index).equals("VB"))
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern36(List<String> cleanTokens, List<String> posTags){

        int index = 0;

        //find MD
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            String token = cleanTokens.get(i);
            index = i;
            if(pos.equalsIgnoreCase("MD") || token.equalsIgnoreCase("'d")){
                index++;
                //find "rather"
                if(index >= cleanTokens.size() || !cleanTokens.get(index).equalsIgnoreCase("rather"))
                    continue;

                //find VB
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern37(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VB","VBG","VBD","VBZ","VBP","VBN"};
        String[] conj = {"if","where","when","that"};
        String[] clause = {"IN","VBG"};
        String[] symbols = {",","!","?",";"};
        String[] be = {"is","was","are","were","be","been","am","'m","'re","'s"};
        //find verb
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(pos,verb) && !hasToken(token,be)){
                //find error_term
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),error_term_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find conj
                flex = 4;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),conj) || hasToken(posTags.get(index),clause)){
                        isFind =true;
                        break;
                    } else if (hasToken(cleanTokens.get(index),symbols)) {
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern38(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] be = {"is","was","are","were"};
        String[] term = {"problem","issue","thing","problems","issues","things"};
        String[] subject = {"PRP","PRP$","NN","NNS","NNP"};
        //find "problem"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,term)){
                //find "is"
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),be)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                flex = 5;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern39(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VB","VBG","VBD","VBZ","VBP","VBN"};
        //find verb
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            if(hasToken(pos,verb)){
                //find error_term
                int flex = 6;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),error_term_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern40(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] neg = {"not","n't","never"};
        String[] verb = {"VB","VBG","VBD","VBZ","VBP","VBN"};
        String[] verb_exclude = {"want","need","seem","matter"};

        Set<String> set = new HashSet<>();
        for (String word : verb_exclude) {
            set.add(word);
            set.addAll(getTense(word,"all"));
        }
        List<String> verb_exclude_list = new ArrayList<>(set);
        //find verb
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,neg)){
                //find VB
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb) && !hasToken(cleanTokens.get(index),verb_exclude_list) && !hasToken(cleanTokens.get(index),verb_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern41(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] subject = {"PRP","PRP$","NN","NNS","NNP","VB"};

        //find negative verb
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,verb_list)){
                //find subject
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern42(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] identifier = {"message","getting","issue","failed","warning"};
        String[] subject = {"NN","NNS","NNP","MD","JJ","DT","PRP","PRP$"};
        String[] symbol = {":","'","\"","``","`"};
        //find identifier ending in "error"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,identifier) || token.toLowerCase().contains("error") || token.toLowerCase().contains("exception")){
                //find symbol
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),symbol)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find subject
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject) || cleanTokens.get(index).toLowerCase().contains("http")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern43(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        //find VB
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            if(hasToken(pos,verb)){
                //find undesired adj
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),undesired_adj)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern44(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        String[] neg_aux = {"not","n't"};
        String[] adv_adj = {"JJ","JJR","JJS","RB","RBR","RBS"};
        //find VB
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            if(hasToken(pos,verb)){
                //find "not"
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),neg_aux)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find adj
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),adv_adj) && !hasToken(cleanTokens.get(index),undesired_adj)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern45(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] seem = {"seem","seems","seemed"};
        String[] neg_aux = {"not","n't"};


        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;

            //find "not"
            if(hasToken(token,neg_aux)){
                //find "seem"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),seem)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "to"
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find VB
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            } else if (hasToken(token,seem)) { //find "seem"
                //find "not"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),neg_aux)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "to"
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find VB
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("VB")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern46(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] take = {"took","take","taking","takes"};
        String[] adv = {"almost","longer","huge","lot"};
        String[] time = {"millisecond","second","minute","hour","day","week","month","year","time"};
        String[] time_abbr = {"s","ms","sec","min","h"};

        Set<String> set = new HashSet<>();
        for (String word : time) {
            set.add(word);
            set.add(getPlural(word));
        }
        List<String> time_list = new ArrayList<>(set);



        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;

            //find "take"
            if(hasToken(token,take)){
                //find "almost"
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),adv)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find time
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),time_list)){
                        isFind =true;
                        break;
                    } else if (Character.isDigit(cleanTokens.get(index).charAt(0))){
                        for (String abbr : time_abbr) {
                            if (cleanTokens.get(index).contains(abbr)){
                                isFind =true;
                                break;
                            }
                        }

                        if(isFind)
                            break;
                        else
                            continue;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;


                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern47(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] no = {"no","neither"};
        String[] nothing = {"nothing","none"};
        String[] noun = {"NN","NNS","NNP"};
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            //find "no"
            if(hasToken(token,no)){
                //find noun
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find VB
                flex = 4;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb) && !hasToken(cleanTokens.get(index),verb_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            } else if (hasToken(token,nothing)) {//find "nothing"
                //find VB
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb) && !hasToken(cleanTokens.get(index),verb_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern48(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] there = {"there","here","these","this","below"};
        String[] be = {"is","was","are","were","be","been","'s","'re"};
        String[] noun = {"NN","NNS","NNP"};
        //find "there"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,there)){
                //find be
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),be)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;


                //find "no"
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("no") || cleanTokens.get(index).equalsIgnoreCase("nothing")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if(cleanTokens.get(index).equalsIgnoreCase("no")){
                    //find noun
                    flex = 2;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),noun) && !hasToken(cleanTokens.get(index),error_term_list)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                } else if (cleanTokens.get(index).equalsIgnoreCase("nothing")) {
                    //not find undesired adjective
                    flex = 2;
                    index++;
                    isFind = true;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(cleanTokens.get(index),undesired_adj)){
                            isFind =false;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                }

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern49(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] noun = {"NN","NNS","NNP"};
        String[] neg = {"not","n't","never"};
        String[] be = {"is","was","are","were","be","been","am","'m","'re","'s"};
        //find be
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,be)){
                //find neg
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),neg)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "in"
                flex = 1;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("in")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find noun
                flex = 4;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern50(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        String[] rb = {"still","already","always","often","usually"};
        //find "but"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("but")){
                //find RB
                int flex = 5;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),rb) || hasToken(posTags.get(index),verb)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if(hasToken(cleanTokens.get(index),rb)){
                    //find VB
                    flex = 3;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),verb)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                } else if (hasToken(posTags.get(index),verb)) {
                    //find RB
                    flex = 3;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(cleanTokens.get(index),rb)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                }

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern51(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] make = {"make","makes","made","making"};
        String[] noun = {"NN","NNS","NNP","PRP","PRP$"};
        //find "make"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,make)){
                //find noun
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find undesired adj
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),undesired_adj)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern52(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] term_end = {"ended","ending","ends","end"};

        //find "end"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,term_end)){
                //find "up"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("up")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find IN
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("IN")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern53(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] noun = {"NN","NNS","NNP"};

        //find "surprised"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("surprised")){
                //find "that"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("that")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find noun
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern54(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] noun = {"NN","NNS","NNP","PRP","PRP$"};
        String[] notice = {"notice","noticed"};

        //find "noticed"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,notice)){
                //find noun
                int flex = 4;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern55(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB","NN"};

        //find "no"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("no")){
                //find "longer"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("longer")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find VB
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb) && !hasToken(cleanTokens.get(index),verb_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern56(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        String[] no = {"no","0"};
        String[] noun = {"NN","NNS","NNP"};
        String[] be = {"is","was","are","were","be","been","am","'m","'re","'s"};
        //find VB
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(pos,verb) && !hasToken(token,be)){
                //find "no"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),no)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find noun
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),noun)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern57(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] no = {"no","only"};
        String[] noun = {"NN","NNS","NNP"};

        //find "with"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("with")){
                //find "no" or "only"
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),no)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if(cleanTokens.get(index).equalsIgnoreCase("no")){
                    //find noun
                    flex = 2;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),noun)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                } else if (cleanTokens.get(index).equalsIgnoreCase("only")) {
                    //find VBG
                    flex = 2;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(posTags.get(index).equalsIgnoreCase("VBG")){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                }


                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern58(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] find = {"find","finding","found","finds"};

        //find "find"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,find)){
                //find PRP
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("PRP")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "hard" or "having"
                flex = 1;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("hard") || cleanTokens.get(index).equalsIgnoreCase("having")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "to"
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("to")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern59(List<String> cleanTokens, List<String> posTags){

        int index = 0;

        //find "is"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("is")){
                //find "this"
                int flex = 1;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("this")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find error_term
                flex = 4;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),error_term_list)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern60(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        String[] subject = {"NN","NNS","NNP","PRP"};

        String[] verb_exclude = {"want","need","seem","matter"};

        Set<String> set = new HashSet<>();
        for (String word : verb_exclude) {
            set.add(word);
            set.addAll(getTense(word,"all"));
        }
        List<String> verb_exclude_list = new ArrayList<>(set);

        //find subject
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            if(hasToken(pos,subject)){
                //find vb or "only"
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if((hasToken(posTags.get(index),verb) && !hasToken(cleanTokens.get(index),verb_exclude)) || cleanTokens.get(index).equalsIgnoreCase("only")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if(cleanTokens.get(index).equalsIgnoreCase("only")){
                    //find vb
                    flex = 3;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),verb) && !hasToken(cleanTokens.get(index),verb_exclude)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                } else if (hasToken(posTags.get(index),verb)) {
                    //find "only"
                    flex = 3;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(cleanTokens.get(index).equalsIgnoreCase("only")){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                }

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern61(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] subject = {"NN","NNS","NNP","PRP"};
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};

        //find subject
        for(int i = 0; i < cleanTokens.size(); i++) {
            String pos = posTags.get(i);
            index = i;
            if(hasToken(pos,subject)){
                //find VB
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "too"
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("too")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find adj
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("JJ")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern62(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] be = {"is","was","are","were","be","been"};

        //find error term
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,error_term_list)){
                //find VB
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),be)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find IN
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("IN")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern63(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] etd_idf = {"want","need","try","should","would"};
        String[] contrast = {"but","however","while"};
        String[] subject = {"NN","NNS","NNP","PRP"};
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};

        Set<String> set = new HashSet<>();
        for (String word : etd_idf) {
            set.add(word);
            set.addAll(getTense(word,"all"));
        }
        List<String> etd_idf_list = new ArrayList<>(set);

        //find etd identifier
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(hasToken(token,etd_idf_list)){
                //find "but"
                int flex = cleanTokens.size()-i;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),contrast)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find subject
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find VB
                flex = 3;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern64(List<String> cleanTokens, List<String> posTags){

        int index = 0;

        //find "stuck"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("stuck")){
                //find IN or VBG
                int flex = 3;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(posTags.get(index).equalsIgnoreCase("IN") || posTags.get(index).equalsIgnoreCase("VBG")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern65(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] conj = {"to","with"};
        String[] noun = {"NN","NNS","NNP"};

        //find "struggling"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("struggling")){
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),conj)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                if(cleanTokens.get(index).equalsIgnoreCase("with")){
                    //find noun
                    flex = 3;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(hasToken(posTags.get(index),noun)){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;

                } else if (cleanTokens.get(index).equalsIgnoreCase("to")) {
                    //find VB
                    flex = 2;
                    index++;
                    isFind = false;
                    while(index < cleanTokens.size() && flex > 0){
                        if(posTags.get(index).equalsIgnoreCase("VB")){
                            isFind =true;
                            break;
                        }

                        index++;
                        flex--;
                    }
                    if(!isFind)
                        continue;
                }

                return true;
            }

        }


        return false;
    }

    public static boolean hasPattern66(List<String> cleanTokens, List<String> posTags){

        int index = 0;
        String[] subject = {"NN","NNS","NNP","PRP","PRP$"};
        String[] verb = {"VBZ","VBD","VBP","VBN","VBG","VB"};
        String[] should = {"shall","should","need","would"};

        //find "but"
        for(int i = 0; i < cleanTokens.size(); i++) {
            String token = cleanTokens.get(i);
            index = i;
            if(token.equalsIgnoreCase("but")){
                //find subject
                int flex = 2;
                index++;
                boolean isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),subject)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find VB
                flex = 2;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(posTags.get(index),verb)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "where"
                flex = cleanTokens.size()-index;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(cleanTokens.get(index).equalsIgnoreCase("where")){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                //find "should"
                flex = cleanTokens.size()-index;
                index++;
                isFind = false;
                while(index < cleanTokens.size() && flex > 0){
                    if(hasToken(cleanTokens.get(index),should)){
                        isFind =true;
                        break;
                    }

                    index++;
                    flex--;
                }
                if(!isFind)
                    continue;

                return true;
            }

        }


        return false;
    }



    public static boolean hasToken(String word, String[] tokens){
        for(String token : tokens) {
            if(word.equalsIgnoreCase(token))
                return true;
        }

        return false;
    }

    public static boolean hasToken(String word, List<String> tokens){
        for(String token : tokens) {
            if(word.equalsIgnoreCase(token))
                return true;
        }

        return false;
    }

    public static String getPlural(String term){
        Lexicon lexicon=Lexicon.getDefaultLexicon();
        WordElement word = lexicon.getWord(term, LexicalCategory.NOUN);
        word.setPlural(true);
        Realiser realiser=new Realiser(lexicon);
        return realiser.realise(word).toString();
    }

    public static List<String> getTense(String term, String tense){
        List<String> result_list = new ArrayList<>();

        Lexicon lexicon=Lexicon.getDefaultLexicon();

        NLGFactory nlgFactory=new NLGFactory(lexicon);
        Realiser realiser=new Realiser(lexicon);
        SPhraseSpec p=nlgFactory.createClause();
        p.setVerb(term);

        String verb_tense = "";
        Set<String> alltense = new HashSet<>();


        if(tense.equalsIgnoreCase("past")){
            p.setFeature(Feature.TENSE, Tense.PAST);
            verb_tense = realiser.realise(p).toString();
        } else if (tense.equalsIgnoreCase("present")) {
            p.setFeature(Feature.TENSE, Tense.PRESENT);
            verb_tense = realiser.realise(p).toString();
        } else if (tense.equalsIgnoreCase("past_participle")) {
            p.setFeature(Feature.FORM, Form.PAST_PARTICIPLE);
            verb_tense = realiser.realise(p).toString();
        } else if (tense.equalsIgnoreCase("present_participle")) {
            p.setFeature(Feature.FORM, Form.PRESENT_PARTICIPLE);
            verb_tense = realiser.realise(p).toString();
        }else{
            p.setFeature(Feature.TENSE, Tense.PAST);
            alltense.add(realiser.realise(p).toString());
            p.setFeature(Feature.TENSE, Tense.PRESENT);
            alltense.add(realiser.realise(p).toString());
            p.setFeature(Feature.FORM, Form.PAST_PARTICIPLE);
            alltense.add(realiser.realise(p).toString());
            p.setFeature(Feature.FORM, Form.PRESENT_PARTICIPLE);
            alltense.add(realiser.realise(p).toString());

            return new ArrayList<>(alltense);
        }

        result_list.add(verb_tense);

        return result_list;
    }

    public static List<String> tokenCleaning(List<CoreLabel> tokens){
        List<String> result_list = new ArrayList<>();

        for (int i = 0; i < tokens.size(); i++) {
            int num_digit = count_digit(i + 1);

            String token = tokens.get(i).toString();
            String word = token.substring(0, token.length() - num_digit - 1);
            result_list.add(word);
        }

        return result_list;
    }

    public static void createPOSForAll(StanfordCoreNLP pipeline){
        int counter = 1;

        for (String issue : issues) {
            counter++;
            System.out.println(counter);
//            System.out.println("Issue:");
//            System.out.println(issue);

            // create a document object
            CoreDocument document = new CoreDocument(issue);
            // annnotate the document
            pipeline.annotate(document);

            String annotations = "";
            String[] data = new String[1];

            for (CoreSentence sentence : document.sentences()) {
//                System.out.println("Sentence:");
//                System.out.println(sentence);

                List<CoreLabel> tokens = sentence.tokens();
                List<String> posTags = sentence.posTags();

                String result_str = "";

                for (int i = 0; i < tokens.size(); i++) {
                    int num_digit = count_digit(i + 1);

                    String token = tokens.get(i).toString();
                    String word = token.substring(0, token.length() - num_digit - 1);
                    String pos = posTags.get(i);

                    if (word.equals(pos))
                        result_str += pos + " ";
                    else
                        result_str += word + "-" + posTags.get(i) + " ";
                }

//                System.out.println("Pos tags:");
//                System.out.println(result_str.trim());
                annotations += result_str.trim() + " ";
            }

            data[0] = annotations;

            list.add(data);

//            System.out.println("Pos tags:");
//            System.out.println(annotations.trim());
//            System.out.println();


            if(counter % 200 == 0){
                writeToCSV("_"+counter+".csv");
                list.clear();
            }
        }
    }

    // Function to check string is alphanumeric or not
    public static boolean isAlphaNumeric(String str)
    {
        for (int i=0; i<str.length(); i++) {
            char c = str.charAt(i);
            if (!Character.isLetterOrDigit(c))
                return false;
        }

        return true;
    }

    public static int count_digit(int num){
        int dig = 1;
        while(num >=10){
            num /= 10;
            dig++;
        }

        return dig;
    }

    public static void readPattern(){
        try{
            // Create an object of file reader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(patternFile);

            // create csvReader object and skip first Line
            CSVReader csvReader = new CSVReaderBuilder(filereader)
                    .withSkipLines(1)
                    .build();
            List<String[]> allData = csvReader.readAll();
            int start_index = 1;
            int skip_num = 100;

            for (String[] row : allData) {
                if(start_index < skip_num) {
                    pattern_code.putIfAbsent(Integer.parseInt(row[0]),row[1]);
                }else
                    break;
                start_index++;
            }

            System.out.println("Total patterns:"+pattern_code.size());
        }catch (IOException e){
            System.out.println("Not writing successfully!");
        }catch (CsvException csvException){
            System.out.println("Not reading csv successfully!");
        }
    }

    public static void readDocs(){
        try{
            // Create an object of file reader
            // class with CSV file as a parameter.
            FileReader filereader = new FileReader(inputFile);

            // create csvReader object and skip first Line
            CSVReader csvReader = new CSVReaderBuilder(filereader)
                    .withSkipLines(1)
                    .build();
            List<String[]> allData = csvReader.readAll();
            int start_index = 1;
            int skip_num = 1001;

            for (String[] row : allData) {
                if(start_index < skip_num) {
                    issues.add(row[0]);
                }else
                    break;
                start_index++;
            }

            System.out.println("Total issues:"+issues.size());
        }catch (IOException e){
            System.out.println("Not writing successfully!");
        }catch (CsvException csvException){
            System.out.println("Not reading csv successfully!");
        }
    }

    public static void writeToCSV(String filename){
        File file = new File(outputFile+filename);

        try {
            if (toCSV){
                // create FileWriter object with file as parameter
                FileWriter outputfile = new FileWriter(file);

                // create CSVWriter object filewriter object as parameter
                CSVWriter writer = new CSVWriter(outputfile);
                writer.writeAll(list);
                // closing writer connection
                writer.close();
            }

        }catch (IOException e){
            System.out.println("Query open incorrectly!");
        }


    }

}
